# IT0123 DevNet Resource Validation Plan

## Student and Project

- Name: Daniel Sta. Rosa
- Section: TN32
- Repository name: `it0123-devnet-resource-plan`

## Purpose

Identifying the correct DevNet resource matters because you need to know what kind of utility you want to have. There are cases that your selected resource may be unnecessary for the application you are using, or even that the selected resource might not be enough to handle the purpose of what you want to handle.

## Validated Resource Decisions

Summarize your four selections from `student_plan.json`. For each use case, state the selected resource, the most important requirement, and the official Cisco evidence used.

always-on-sandbox - immediate acces, shared environment, no admin access, no reservation needed.

reservation-sandbox - private environment with admin accesss, with tools, but needs reservation and vpn connection.

learning-lab - curated learning materials in a controlled environment

code-exchange - code repositories that provide code examples and automation use cases.

## AI Evaluation

always-on-sandbox - Accepted. Keword is immediate access, and always-on-sandbox provides that.

## Validation Evidence

- Validator result:
- Command used: python validate_plan.py
- Official Cisco pages reviewed:

## Git Evidence

- Initial commit message: Added README.md
- Validation commit message: Validated student_plan.json
- Output of `git log --oneline`:

0ec7b17 (HEAD -> master) Verified student_plan.json
7e52873 Added student_plan.json
ca4c477 Added README.md

## AI-Use Disclosure

AI Used: ChatGPT

Only used AI for selecting resource type. Independently verified links provided by the AI and cross-referenced its rationale.
